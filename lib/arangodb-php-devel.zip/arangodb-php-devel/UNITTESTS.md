# PHPUnit Tests for ArangoDB-PHP

To run the unit tests, cd into the `tests` folder and run:

```
phpunit --testsuite ArangoDB-PHP
```
