<?php

namespace ArangoDBClient;

require __DIR__ . '/lib/ArangoDBClient/Autoloader.php';

Autoloader::init();
